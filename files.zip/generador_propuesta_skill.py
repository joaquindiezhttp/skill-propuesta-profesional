#!/usr/bin/env python3
"""
SKILL: Generador de Propuesta Profesional
Autor: Joaco
Versión: 1.0.0

Genera propuestas comerciales profesionales en Word (.docx)
basadas en información del cliente y proyecto.
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, Optional
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


class SkillValidationError(Exception):
    """Excepción para errores de validación"""
    pass


class SkillGeneradorPropuesta:
    """
    Skill para generar propuestas profesionales en Word.
    
    Toma como entrada información del cliente y proyecto,
    genera una propuesta profesional en 7-8 secciones.
    """
    
    # Datos por sector para enriquecer propuestas
    SECTOR_DATA = {
        "gastronomía": {
            "tendencias": ["especialidad", "autenticidad", "experiencia", "sostenibilidad"],
            "colores_tipicos": ["rojo", "negro", "dorado", "blanco"],
            "ejemplos": ["Negro Cueva de Café", "Sosa Café", "Chiamo"],
            "presupuesto_tipico": (800, 2000)
        },
        "música": {
            "tendencias": ["originalidad", "energía", "identidad", "movimiento"],
            "colores_tipicos": ["negro", "neon", "colores vibrantes"],
            "ejemplos": ["The Beatles", "Queen", "Arctic Monkeys"],
            "presupuesto_tipico": (1000, 3000)
        },
        "retail": {
            "tendencias": ["minimalismo", "experiencia", "digital", "sostenibilidad"],
            "colores_tipicos": ["blanco", "negro", "colores corporativos"],
            "ejemplos": ["Uniqlo", "ZARA", "Apple"],
            "presupuesto_tipico": (1500, 5000)
        },
        "tech": {
            "tendencias": ["innovación", "claridad", "modernidad", "escalabilidad"],
            "colores_tipicos": ["azul", "blanco", "gris"],
            "ejemplos": ["Stripe", "Vercel", "Figma"],
            "presupuesto_tipico": (2000, 10000)
        }
    }
    
    def __init__(self):
        """Inicializar la skill"""
        self.documento = None
        self.estilos = None
        self.client_data = {}
        
    def validar_entrada(self, entrada: Dict[str, Any]) -> bool:
        """
        Valida que la entrada tenga todos los datos requeridos.
        
        Args:
            entrada: Dict con datos del cliente y proyecto
            
        Returns:
            bool: True si es válido
            
        Raises:
            SkillValidationError: Si faltan datos requeridos
        """
        campos_requeridos = [
            "cliente_nombre",
            "sector",
            "presupuesto_usd",
            "timeline_semanas"
        ]
        
        for campo in campos_requeridos:
            if campo not in entrada or not entrada[campo]:
                raise SkillValidationError(
                    f"Campo requerido faltante: {campo}"
                )
        
        # Validar que sector esté en opciones válidas
        sectores_validos = list(self.SECTOR_DATA.keys()) + ["otro"]
        if entrada["sector"] not in sectores_validos:
            raise SkillValidationError(
                f"Sector inválido. Debe ser uno de: {', '.join(sectores_validos)}"
            )
        
        # Validar presupuesto y timeline
        if entrada["presupuesto_usd"] < 100:
            raise SkillValidationError("Presupuesto mínimo: $100")
        
        if entrada["timeline_semanas"] < 1:
            raise SkillValidationError("Timeline mínimo: 1 semana")
        
        return True
    
    def enriquecer_datos(self, entrada: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enriquece los datos de entrada con información sector-específica.
        
        Args:
            entrada: Dict original con datos del cliente
            
        Returns:
            Dict enriquecido con información adicional
        """
        datos_enriquecidos = entrada.copy()
        
        sector = entrada.get("sector", "otro")
        
        if sector in self.SECTOR_DATA:
            sector_info = self.SECTOR_DATA[sector]
            datos_enriquecidos["tendencias"] = sector_info["tendencias"]
            datos_enriquecidos["competencia"] = sector_info["ejemplos"]
            datos_enriquecidos["presupuesto_recomendado"] = sector_info["presupuesto_tipico"]
        
        # Validar presupuesto contra recomendación
        if "presupuesto_recomendado" in datos_enriquecidos:
            min_reco, max_reco = datos_enriquecidos["presupuesto_recomendado"]
            presupuesto = entrada["presupuesto_usd"]
            
            if presupuesto < min_reco:
                datos_enriquecidos["alerta_presupuesto"] = f"⚠️ Presupuesto bajo para {sector} (típico: ${min_reco}-${max_reco})"
        
        return datos_enriquecidos
    
    def crear_documento(self, datos: Dict[str, Any]) -> Document:
        """
        Crea el documento Word con la propuesta.
        
        Args:
            datos: Dict con datos enriquecidos
            
        Returns:
            Document: Documento Word creado
        """
        doc = Document()
        
        # Configurar márgenes (1 pulgada)
        secciones = doc.sections
        for seccion in secciones:
            seccion.top_margin = Inches(1)
            seccion.bottom_margin = Inches(1)
            seccion.left_margin = Inches(1)
            seccion.right_margin = Inches(1)
        
        # SECCIÓN 1: PORTADA
        self._agregar_portada(doc, datos)
        doc.add_page_break()
        
        # SECCIÓN 2: RESUMEN EJECUTIVO
        self._agregar_resumen_ejecutivo(doc, datos)
        
        # SECCIÓN 3: DIAGNÓSTICO
        self._agregar_diagnostico(doc, datos)
        
        # SECCIÓN 4: PROPUESTA
        self._agregar_propuesta(doc, datos)
        
        # SECCIÓN 5: ENTREGAS
        self._agregar_entregas(doc, datos)
        
        # SECCIÓN 6: TIMELINE
        self._agregar_timeline(doc, datos)
        
        # SECCIÓN 7: INVERSIÓN
        self._agregar_inversion(doc, datos)
        
        # SECCIÓN 8: NEXT STEPS
        self._agregar_next_steps(doc, datos)
        
        return doc
    
    def _agregar_portada(self, doc: Document, datos: Dict[str, Any]):
        """Agrega portada al documento"""
        # Título
        titulo = doc.add_paragraph()
        titulo.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = titulo.add_run(datos.get("cliente_nombre", "Cliente"))
        run.font.size = Pt(36)
        run.font.bold = True
        run.font.color.rgb = RGBColor(26, 26, 26)  # Negro #1A1A1A
        
        # Subtítulo
        subtitulo = doc.add_paragraph()
        subtitulo.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = subtitulo.add_run("Propuesta de Branding")
        run.font.size = Pt(24)
        run.font.color.rgb = RGBColor(212, 165, 116)  # Caramelo #D4A574
        
        # Descripción
        desc = doc.add_paragraph()
        desc.alignment = WD_ALIGN_PARAGRAPH.CENTER
        desc_text = datos.get("proyecto_descripcion", "Rediseño de identidad visual")
        run = desc.add_run(desc_text)
        run.font.size = Pt(14)
        run.font.italic = True
        
        # Espacio
        doc.add_paragraph()
        doc.add_paragraph()
        
        # Fecha
        fecha = doc.add_paragraph()
        fecha.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = fecha.add_run(f"Propuesta: {datetime.now().strftime('%B de %Y')}")
        run.font.size = Pt(11)
        run.font.color.rgb = RGBColor(128, 128, 128)  # Gris
    
    def _agregar_resumen_ejecutivo(self, doc: Document, datos: Dict[str, Any]):
        """Agrega sección de Resumen Ejecutivo"""
        doc.add_heading("Resumen Ejecutivo", level=1)
        
        resumen = f"""
{datos.get('cliente_nombre', 'El cliente')} es una {datos.get('tipo_negocio', 'empresa')} ubicada en {datos.get('cliente_ubicacion', 'una ubicación estratégica')}.

Esta propuesta presenta un rediseño integral de identidad visual que comunique modernidad, profesionalismo y los valores únicos del negocio.

El proyecto incluye: logo profesional, paleta de colores estratégica, tipografía contemporánea, manual de marca completo y aplicaciones en múltiples soportes.
"""
        doc.add_paragraph(resumen.strip())
    
    def _agregar_diagnostico(self, doc: Document, datos: Dict[str, Any]):
        """Agrega sección de Diagnóstico"""
        doc.add_heading("Diagnóstico", level=1)
        
        doc.add_heading("Situación Actual", level=2)
        doc.add_paragraph(
            f"Actualmente, {datos.get('cliente_nombre', 'la marca')} enfrenta desafíos en diferenciación visual y reconocimiento de marca en el mercado de {datos.get('sector', 'su sector')}."
        )
        
        doc.add_heading("Oportunidades Identificadas", level=2)
        doc.add_paragraph(
            f"El sector de {datos.get('sector', 'la industria')} muestra tendencias hacia: {', '.join(datos.get('tendencias', ['modernidad', 'autenticidad']))}"
        )
    
    def _agregar_propuesta(self, doc: Document, datos: Dict[str, Any]):
        """Agrega sección de Propuesta"""
        doc.add_heading("Nuestra Propuesta", level=1)
        
        doc.add_heading("Concepto", level=2)
        concepto = datos.get('proyecto_diferenciador', 'Una identidad visual única y memorable')
        doc.add_paragraph(f"Desarrollaremos una solución que represente: {concepto}")
        
        doc.add_heading("Enfoque", level=2)
        doc.add_paragraph(
            "Nuestro enfoque combina investigación de mercado, análisis competitivo y creatividad estratégica para desarrollar una identidad que no solo sea visualmente atractiva, sino también estratégicamente efectiva."
        )
    
    def _agregar_entregas(self, doc: Document, datos: Dict[str, Any]):
        """Agrega tabla de entregas"""
        doc.add_heading("Entregas", level=1)
        
        entregas_default = [
            "Logo principal + variantes",
            "Manual de marca (40 páginas)",
            "Paleta de colores",
            "Tipografía recomendada",
            "Mockups en diversos soportes",
            "Archivos en formatos web e impresión"
        ]
        
        # Crear tabla
        tabla = doc.add_table(rows=len(entregas_default) + 1, cols=1)
        tabla.style = 'Light Grid Accent 1'
        
        # Header
        header = tabla.rows[0].cells[0]
        header.text = "Entregable"
        
        # Entregas
        for i, entrega in enumerate(entregas_default, 1):
            tabla.rows[i].cells[0].text = f"✓ {entrega}"
    
    def _agregar_timeline(self, doc: Document, datos: Dict[str, Any]):
        """Agrega tabla de timeline"""
        doc.add_heading("Timeline", level=1)
        
        semanas = datos.get('timeline_semanas', 4)
        
        tabla = doc.add_table(rows=4, cols=3)
        tabla.style = 'Light Grid Accent 1'
        
        # Headers
        tabla.rows[0].cells[0].text = "Fase"
        tabla.rows[0].cells[1].text = "Duración"
        tabla.rows[0].cells[2].text = "Entrega"
        
        # Fases
        tabla.rows[1].cells[0].text = "Concepto"
        tabla.rows[1].cells[1].text = f"{int(semanas * 0.25)} días"
        tabla.rows[1].cells[2].text = "3 opciones de diseño"
        
        tabla.rows[2].cells[0].text = "Refinamiento"
        tabla.rows[2].cells[1].text = f"{int(semanas * 0.35)} días"
        tabla.rows[2].cells[2].text = "Logo final"
        
        tabla.rows[3].cells[0].text = "Entrega"
        tabla.rows[3].cells[1].text = f"{int(semanas * 0.40)} días"
        tabla.rows[3].cells[2].text = "Manual + mockups"
        
        doc.add_paragraph(f"\nDuración total: {semanas} semanas")
    
    def _agregar_inversion(self, doc: Document, datos: Dict[str, Any]):
        """Agrega tabla de inversión"""
        doc.add_heading("Inversión", level=1)
        
        presupuesto = datos.get('presupuesto_usd', 1000)
        
        tabla = doc.add_table(rows=5, cols=2)
        tabla.style = 'Light Grid Accent 1'
        
        # Headers
        tabla.rows[0].cells[0].text = "Concepto"
        tabla.rows[0].cells[1].text = "USD"
        
        # Desglose
        tabla.rows[1].cells[0].text = "Diseño de identidad visual"
        tabla.rows[1].cells[1].text = f"${int(presupuesto * 0.4)}"
        
        tabla.rows[2].cells[0].text = "Refinamientos e iteraciones"
        tabla.rows[2].cells[1].text = f"${int(presupuesto * 0.3)}"
        
        tabla.rows[3].cells[0].text = "Manual + aplicaciones"
        tabla.rows[3].cells[1].text = f"${int(presupuesto * 0.3)}"
        
        tabla.rows[4].cells[0].text = "TOTAL"
        tabla.rows[4].cells[1].text = f"${presupuesto}"
        
        forma_pago = datos.get('forma_pago', '50-50')
        doc.add_paragraph(f"\nForma de pago: {forma_pago}")
    
    def _agregar_next_steps(self, doc: Document, datos: Dict[str, Any]):
        """Agrega sección de Next Steps"""
        doc.add_heading("Próximos Pasos", level=1)
        
        doc.add_paragraph(
            "1. Revisar esta propuesta y confirmar interés\n"
            "2. Reunión de kickoff para alinear detalles\n"
            "3. Confirmar presupuesto y firma del contrato\n"
            "4. Adelanto del 50% para comenzar trabajo\n"
            "5. Inicio del proyecto en la fecha acordada"
        )
        
        doc.add_paragraph("\n¿Listo para transformar tu marca?")
        doc.add_paragraph("Contacta para comenzar.")
    
    def ejecutar(self, entrada: Dict[str, Any]) -> Dict[str, Any]:
        """
        Ejecuta la skill: valida, enriquece y genera propuesta.
        
        Args:
            entrada: Dict con datos del cliente
            
        Returns:
            Dict con archivo generado y metadatos
        """
        try:
            # PASO 1: VALIDAR
            self.validar_entrada(entrada)
            
            # PASO 2: ENRIQUECER
            datos_enriquecidos = self.enriquecer_datos(entrada)
            
            # PASO 3: GENERAR
            doc = self.crear_documento(datos_enriquecidos)
            
            # PASO 4: GUARDAR
            nombre_archivo = f"{datos_enriquecidos['cliente_nombre'].upper().replace(' ', '_')}_PROPUESTA.docx"
            ruta_archivo = os.path.join("/mnt/user-data/outputs", nombre_archivo)
            doc.save(ruta_archivo)
            
            # PASO 5: RETORNAR
            return {
                "exito": True,
                "archivo": nombre_archivo,
                "ruta_completa": ruta_archivo,
                "archivo_url": f"https://output.vercel.app/{nombre_archivo}",
                "formato": "docx",
                "paginas": len(doc.paragraphs),
                "secciones": [
                    "Portada",
                    "Resumen Ejecutivo",
                    "Diagnóstico",
                    "Propuesta",
                    "Entregas",
                    "Timeline",
                    "Inversión",
                    "Next Steps"
                ],
                "metadata": {
                    "cliente": datos_enriquecidos.get('cliente_nombre'),
                    "sector": datos_enriquecidos.get('sector'),
                    "presupuesto": datos_enriquecidos.get('presupuesto_usd'),
                    "timeline_semanas": datos_enriquecidos.get('timeline_semanas'),
                    "generado_en": datetime.now().isoformat(),
                    "version_skill": "1.0.0"
                }
            }
            
        except SkillValidationError as e:
            return {
                "exito": False,
                "error": str(e),
                "tipo_error": "validation"
            }
        except Exception as e:
            return {
                "exito": False,
                "error": str(e),
                "tipo_error": "execution"
            }


# ===== ENTRADA PRINCIPAL =====
if __name__ == "__main__":
    # Ejemplo de uso
    skill = SkillGeneradorPropuesta()
    
    entrada_ejemplo = {
        "cliente_nombre": "NOI CAFE",
        "sector": "gastronomía",
        "tipo_negocio": "Café specialty + pastelería artesanal",
        "cliente_ubicacion": "San Isidro, Buenos Aires",
        "cliente_publico": "20-35 años, foodies",
        "proyecto_tipo": "branding",
        "proyecto_descripcion": "Rediseño completo de identidad visual",
        "proyecto_diferenciador": "Minimalismo + calidez, representa encuentro y comunidad",
        "presupuesto_usd": 1000,
        "timeline_semanas": 4,
        "forma_pago": "50-50"
    }
    
    resultado = skill.ejecutar(entrada_ejemplo)
    print(json.dumps(resultado, indent=2, ensure_ascii=False))
